//
//  WeiuiRippleComponent.h
//  WeexTestDemo
//
//  Created by apple on 2018/7/2.
//  Copyright © 2018年 TomQin. All rights reserved.
//

#import "WXComponent.h"

@interface WeiuiRippleComponent : WXComponent

@end
