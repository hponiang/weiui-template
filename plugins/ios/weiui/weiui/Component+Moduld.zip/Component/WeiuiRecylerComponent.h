#import "WXScrollerComponent.h"

@interface WeiuiRecylerComponent : WXScrollerComponent

@end
