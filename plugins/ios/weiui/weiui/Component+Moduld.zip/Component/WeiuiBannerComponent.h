//
//  WeiuiBannerComponent.h
//  WeexTestDemo
//
//  Created by apple on 2018/6/2.
//  Copyright © 2018年 TomQin. All rights reserved.
//

#import "WXComponent.h"

@class WeiuiIndicatorView;

@interface WeiuiBannerComponent : WXComponent

- (void)setIndicatorView:(WeiuiIndicatorView *)indicatorView;

@end
