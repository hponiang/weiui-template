//
//  WeiuiGridComponent.h
//  WeexTestDemo
//
//  Created by apple on 2018/6/5.
//  Copyright © 2018年 TomQin. All rights reserved.
//

#import "WXComponent.h"
#import "WeexSDK.h"

@interface WeiuiGridComponent : WXComponent

@end
